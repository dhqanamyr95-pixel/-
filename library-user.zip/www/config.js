/* تنظیمات برنامه
   API_BASE: آدرس سرور (مثلاً "https://USERNAME.pythonanywhere.com"). خالی = حالت آزمایشی بدون سرور
   MYKET_PUBLIC_KEY: کلید عمومی RSA از پنل توسعه‌دهنده‌ی مایکت
   TEST_BILLING: تا وقتی اتصال واقعی مایکت وصل نشده، شارژ آزمایشی فعال باشد (هنگام انتشار false شود) */
window.CONFIG = {
  API_BASE: "",
  MYKET_PUBLIC_KEY: "",
  TEST_BILLING: true,
  TOPUP: [
    { sku: "charge_20k",  amount: 20000 },
    { sku: "charge_50k",  amount: 50000 },
    { sku: "charge_100k", amount: 100000 },
    { sku: "charge_200k", amount: 200000 }
  ]
};
